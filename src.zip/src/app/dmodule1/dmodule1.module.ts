import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DComponent } from './dmodule1/dmodule1.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DComponent]
})
export class DModule { }
